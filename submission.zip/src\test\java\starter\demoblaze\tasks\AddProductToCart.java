package starter.demoblaze.tasks;

import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import starter.demoblaze.page.PageDemoblaze;

public class AddProductToCart {

    public static Performable product(String productName) {
        return Task.where("{0} adds product to cart",
                actor -> actor.attemptsTo(
                        Click.on(PageDemoblaze.PRODUCT_LINK(productName)),
                        Click.on(PageDemoblaze.ADD_TO_CART),
                        // Accept the browser alert after adding to cart
                        // Custom interaction implemented below
                        AcceptAlertInteraction.acceptAlert()
                )
        );
    }

}
