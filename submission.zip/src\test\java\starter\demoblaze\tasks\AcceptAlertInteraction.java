package starter.demoblaze.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import org.openqa.selenium.Alert;

public class AcceptAlertInteraction implements Interaction {

    public static AcceptAlertInteraction acceptAlert() {
        return new AcceptAlertInteraction();
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        try {
            Alert alert = BrowseTheWeb.as(actor).getDriver().switchTo().alert();
            alert.accept();
        } catch (Exception e) {
            // ignore if no alert present
        }
    }
}
